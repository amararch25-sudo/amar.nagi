# Amarjeet Singh — Personal Portfolio Website

A professional personal portfolio for **Amarjeet Singh**, Graphic Designer specializing in 2D Exhibition and Event Design. Built with a corporate/professional aesthetic featuring a rich black color palette with gold accents.

---

## 🌐 Entry Point

| Path | Description |
|------|-------------|
| `index.html` | Main portfolio homepage (single-page application) |

### Sections (anchor links)
| Anchor | Section |
|--------|---------|
| `#home` | Hero / Landing |
| `#about` | About Me |
| `#skills` | Skills & Tools |
| `#projects` | Featured Projects |
| `#contact` | Contact Form |

---

## ✅ Completed Features

- **Hero Section** — Full-viewport hero with name, title, availability badge, animated stats, and call-to-action buttons
- **Navbar** — Fixed, glassmorphism navbar with scroll-aware active link highlighting and mobile hamburger menu
- **About Section** — Bio, avatar with animated rings, expertise highlights
- **Skills Section** — Animated skill bars for Photoshop, InDesign, CorelDRAW + expertise tags
- **Projects Section** — 6 project cards: Saras, BIRC, MedTech, IEEMA, CII, Defence Pavilion
- **Contact Section** — Contact info + form with API persistence via RESTful Table API
- **Footer** — Logo, links, copyright
- **Back to Top Button** — Scroll-triggered floating button
- **Scroll Reveal Animations** — IntersectionObserver-based reveal for all major sections
- **3D Card Tilt** — Subtle mousemove tilt on project cards
- **Mobile Responsive** — Fully responsive for mobile, tablet, and desktop

---

## 🎨 Design System

| Element | Value |
|---------|-------|
| Background | #000000 / #0a0a0a / #111111 |
| Accent | #c9a84c (Gold) |
| Text Primary | #ffffff |
| Text Secondary | #aaaaaa |
| Font (Headings) | Montserrat |
| Font (Body) | Open Sans |
| Style | Corporate / Professional |

---

## 🗄️ Data Models

### Table: `contact_messages`
| Field | Type | Description |
|-------|------|-------------|
| id | text | Unique identifier |
| name | text | Sender's full name |
| email | text | Sender's email |
| subject | text | Message subject |
| message | rich_text | Message body |
| submitted_at | datetime | Submission timestamp |

---

## 📁 File Structure

```
index.html          — Main portfolio page
css/
  style.css         — All styles (corporate black theme)
js/
  main.js           — Navbar, animations, form, interactions
README.md           — Project documentation
```

---

## 🚀 Deployment

To publish the website, go to the **Publish tab** and click publish. The site will be deployed instantly.

---

## 📌 Recommended Next Steps

1. **Add real project images** — Replace placeholder icons with actual project screenshots/photos
2. **Add profile photo** — Replace avatar initials with a real headshot
3. **Add LinkedIn/Behance/portfolio links** — Update social buttons in contact section
4. **Add resume download** — Link a PDF resume to the "Hire Me" button
5. **Extend projects** — Add more detail per project (client, year, dimensions)
6. **Custom domain** — Set up a custom domain after publishing

---

## 👤 Author

**Amarjeet Singh**  
Graphic Designer | 2D Exhibition & Event Design  
📞 +91 9773678977  
📧 pixelperfect2015@gmail.com
